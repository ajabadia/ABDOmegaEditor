/**
    bespoke synth, a software modular synthesizer
    Copyright (C) 2021 Ryan Challinor (contact: awwbees@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
/*
  ==============================================================================

    GlobalControls.h
    Created: 26 Sep 2020 11:34:18am
    Author:  Ryan Challinor

  ==============================================================================
*/

#pragma once
#include <iostream>
#include "IDrawableModule.h"
#include "OpenFrameworksPort.h"
#include "Slider.h"

class GlobalControls : public IDrawableModule, public IFloatSliderListener
{
public:
   GlobalControls();
   virtual ~GlobalControls();
   static IDrawableModule* Create() { return new GlobalControls(); }

   
   void CreateUIControls() override;
   void Poll() override;

   void FloatSliderUpdated(FloatSlider* slider, float oldVal) override;

   void LoadLayout(const ofxJSONElement& moduleInfo) override;
   void SetUpFromSaveData() override;
   void SaveLayout(ofxJSONElement& moduleInfo) override;
   void SaveState(FileStreamOut& out) override;
   void LoadState(FileStreamIn& in) override;
   std::vector<IUIControl*> ControlsToNotSetDuringLoadState() const override;

private:
   //IDrawableModule
   void DrawModule() override;
   bool Enabled() const override { return true; }
   void GetModuleDimensions(float& width, float& height) override;

   FloatSlider* mZoomSlider;
   FloatSlider* mXSlider;
   FloatSlider* mYSlider;
   FloatSlider* mMouseScrollXSlider;
   FloatSlider* mMouseScrollYSlider;
   FloatSlider* mBackgroundLissajousRSlider;
   FloatSlider* mBackgroundLissajousGSlider;
   FloatSlider* mBackgroundLissajousBSlider;
   FloatSlider* mBackgroundRSlider;
   FloatSlider* mBackgroundGSlider;
   FloatSlider* mBackgroundBSlider;

   float mWidth;
   float mHeight;
   float mMouseScrollX;
   float mMouseScrollY;
};