/**
    bespoke synth, a software modular synthesizer
    Copyright (C) 2021 Ryan Challinor (contact: awwbees@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
//
//  LaunchpadNoteDisplayer.h
//  modularSynth
//
//  Created by Ryan Challinor on 4/16/13.
//
//

#ifndef __modularSynth__LaunchpadNoteDisplayer__
#define __modularSynth__LaunchpadNoteDisplayer__

#include <iostream>
#include "NoteEffectBase.h"
#include "IDrawableModule.h"
#include "TextEntry.h"

class LaunchpadKeyboard;

class LaunchpadNoteDisplayer : public NoteEffectBase, public IDrawableModule
{
public:
   LaunchpadNoteDisplayer();
   static IDrawableModule* Create() { return new LaunchpadNoteDisplayer(); }
   
   

   void SetLaunchpad(LaunchpadKeyboard* launchpad) { mLaunchpad = launchpad; }

   //INoteReceiver
   void PlayNote(double time, int pitch, int velocity, int voiceIdx = -1, ModulationParameters modulation = ModulationParameters()) override;
   
   virtual void LoadLayout(const ofxJSONElement& moduleInfo) override;
   virtual void SetUpFromSaveData() override;
   
   
private:
   //IDrawableModule
   void DrawModule() override;
   void DrawModuleUnclipped() override;
   void GetModuleDimensions(float& width, float& height) override { width = 80; height = 0; }
   bool Enabled() const override { return true; }

   LaunchpadKeyboard* mLaunchpad;
};

#endif /* defined(__modularSynth__LaunchpadNoteDisplayer__) */
