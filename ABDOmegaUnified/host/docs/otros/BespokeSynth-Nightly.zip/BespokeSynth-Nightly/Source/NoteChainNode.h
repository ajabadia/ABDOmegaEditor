/**
    bespoke synth, a software modular synthesizer
    Copyright (C) 2021 Ryan Challinor (contact: awwbees@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
//
//  NoteChainNode.h
//  Bespoke
//
//  Created by Ryan Challinor on 5/1/16.
//
//

#ifndef __Bespoke__NoteChainNode__
#define __Bespoke__NoteChainNode__

#include "IDrawableModule.h"
#include "INoteSource.h"
#include "ClickButton.h"
#include "TextEntry.h"
#include "Slider.h"
#include "Transport.h"
#include "DropdownList.h"
#include "IPulseReceiver.h"

class NoteChainNode : public IDrawableModule, public INoteSource, public IButtonListener, public ITextEntryListener, public IFloatSliderListener, public IAudioPoller, public IDropdownListener, public ITimeListener, public IPulseSource, public IPulseReceiver
{
public:
   NoteChainNode();
   virtual ~NoteChainNode();
   static IDrawableModule* Create() { return new NoteChainNode(); }
   
   
   void CreateUIControls() override;
   void Init() override;
   
   void SetEnabled(bool enabled) override { mEnabled = enabled; }
   
   //IPulseReceiver
   void OnPulse(double time, float velocity, int flags) override;
   
   void OnTimeEvent(double time) override;
   void OnTransportAdvanced(float amount) override;
   
   void PostRepatch(PatchCableSource* cableSource, bool fromUserClick) override;
   
   void CheckboxUpdated(Checkbox* checkbox) override;
   void ButtonClicked(ClickButton* button) override;
   void TextEntryComplete(TextEntry* entry) override;
   void FloatSliderUpdated(FloatSlider* slider, float oldVal) override {}
   void DropdownUpdated(DropdownList* list, int oldVal) override {}
   
   void LoadLayout(const ofxJSONElement& moduleInfo) override;
   void SetUpFromSaveData() override;
   
private:
   //IDrawableModule
   void DrawModule() override;
   bool Enabled() const override { return mEnabled; }
   void GetModuleDimensions(float& w, float& h) override { w=110; h=76; }
   
   void TriggerNote(double time);
   
   ClickButton* mTriggerButton;
   TextEntry* mPitchEntry;
   FloatSlider* mVelocitySlider;
   FloatSlider* mDurationSlider;
   DropdownList* mNextSelector;
   int mPitch;
   float mVelocity;
   float mDuration;
   float mDurationMs;
   NoteInterval mNextInterval;
   float mNext;
   double mStartTime;
   bool mNoteOn;
   bool mWaitingToTrigger;
   bool mQueueTrigger;
   PatchCableSource* mNextNodeCable;
};

#endif /* defined(__Bespoke__NoteChainNode__) */
