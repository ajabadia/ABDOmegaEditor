/**
    bespoke synth, a software modular synthesizer
    Copyright (C) 2021 Ryan Challinor (contact: awwbees@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
//
//  CommentDisplay.h
//  Bespoke
//
//  Created by Ryan Challinor on 2/1/15.
//
//

#ifndef __Bespoke__CommentDisplay__
#define __Bespoke__CommentDisplay__

#include <iostream>
#include "IDrawableModule.h"
#include "OpenFrameworksPort.h"
#include "TextEntry.h"

class CommentDisplay : public IDrawableModule, public ITextEntryListener
{
public:
   CommentDisplay();
   virtual ~CommentDisplay();
   static IDrawableModule* Create() { return new CommentDisplay(); }
   
   
   void CreateUIControls() override;
   
   void TextEntryComplete(TextEntry* entry) override;
   
   void LoadLayout(const ofxJSONElement& moduleInfo) override;
   void SetUpFromSaveData() override;
   void SaveLayout(ofxJSONElement& moduleInfo) override;
   
private:
   //IDrawableModule
   void DrawModule() override;
   bool Enabled() const override { return true; }
   void GetModuleDimensions(float& width, float& height) override;
   
   char mComment[MAX_TEXTENTRY_LENGTH];
   TextEntry* mCommentEntry;
};



#endif /* defined(__Bespoke__CommentDisplay__) */
