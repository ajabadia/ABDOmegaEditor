/**
    bespoke synth, a software modular synthesizer
    Copyright (C) 2021 Ryan Challinor (contact: awwbees@gmail.com)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/
//
//  Muter.h
//  modularSynth
//
//  Created by Ryan Challinor on 3/26/13.
//
//

#ifndef __modularSynth__Muter__
#define __modularSynth__Muter__

#include <iostream>
#include "IAudioEffect.h"
#include "IDrawableModule.h"
#include "Checkbox.h"
#include "Ramp.h"
#include "Slider.h"

class Muter : public IAudioEffect, public IFloatSliderListener
{
public:
   Muter();
   virtual ~Muter();
   
   static IAudioEffect* Create() { return new Muter(); }
   
   
   void CreateUIControls() override;

   //IAudioEffect
   void ProcessAudio(double time, ChannelBuffer* buffer) override;
   void SetEnabled(bool enabled) override {}
   std::string GetType() override { return "muter"; }

   void CheckboxUpdated(Checkbox* checkbox) override;
   void FloatSliderUpdated(FloatSlider* slider, float oldVal) override {}

private:
   void Go();

   //IDrawableModule
   void DrawModule() override;
   void GetModuleDimensions(float& w, float& h) override { w=80; h=38; }
   bool Enabled() const override { return true; }

   bool mPass;

   Checkbox* mPassCheckbox;
   Ramp mRamp;
   float mRampTimeMs;
   FloatSlider* mRampTimeSlider;
};


#endif /* defined(__modularSynth__Muter__) */

